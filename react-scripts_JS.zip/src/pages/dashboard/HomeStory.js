import Page from '../../components/Page';
import { Container } from '@mui/material';

function HomeStory() {
  return (
    <Page>
      <Container>
        <h1>Khang</h1>
      </Container>
    </Page>
  );
}
export default HomeStory;
