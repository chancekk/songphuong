import Page from '../../components/Page';
import { Container } from '@mui/material';

function RememberCard() {
  return (
    <Page>
      <Container>
        <h1>Khang</h1>
      </Container>
    </Page>
  );
}
export default RememberCard;
