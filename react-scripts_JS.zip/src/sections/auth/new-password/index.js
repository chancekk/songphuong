export { default as NewPasswordForm } from './NewPasswordForm';
