export { default as ProductDetailsReview } from './ProductDetailsReview';
export { default as ProductDetailsSummary } from './ProductDetailsSummary';
export { default as ProductDetailsCarousel } from './ProductDetailsCarousel';
export { default as ProductDetailsReviewForm } from './ProductDetailsReview';
export { default as ProductDetailsReviewList } from './ProductDetailsReviewList';
export { default as ProductDetailsReviewOverview } from './ProductDetailsReviewOverview';
