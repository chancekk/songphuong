import Page from '../../components/Page';
import Iconify from '../../components/Iconify';

function RememberCard() {
  return <h1>khang</h1>;
}
export default RememberCard;
